
from distutils.core import setup
setup(name='mymandel',
      version='1.0',
      py_modules=['mandelbrot'],
      )